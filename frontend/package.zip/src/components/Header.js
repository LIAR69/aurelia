import React from "react";
import { SiAuchan } from "react-icons/si";
import { IoHomeSharp } from "react-icons/io5";
import { RiLoginBoxFill } from "react-icons/ri";
import { TiUserAdd } from "react-icons/ti";
import { FaShoppingCart } from "react-icons/fa";
import { Link } from "react-router-dom";
import Mens from '../pages/Mens';
import { useDispatch, useSelector } from "react-redux";
import { logoutRedux } from "../store/loginslice";
// import { loginRedux } from '../store/loginSlice';


function Header() {
    const userData = useSelector(state => state.user1);
  const dispatch = useDispatch();

  const handleLogout = () => {
    dispatch(logoutRedux());
    alert("Logout Success");
  };

const basketData = useSelector((state)=> state.basket.basket)
console.log(basketData)

return (
        <div >
           <header className="w-full px-5 bg-black flex justify-between py-4" >
            <div className=" text-white bg-black flex items-center text-3xl">
            <SiAuchan /> 
                <button className="text-4xl">spireChronos</button>
            </div>
            <Link to={"/Mens"}>
            <button className=" text-white text-2xl hover:scale-150 duration-300 gap-3"  >Mens</button>
            </Link>
            <Link to={"/Womens"}><button className=" text-white text-2xl hover:scale-150 duration-300 gap-2">Womens</button> 
            </Link>
            
            <div className="flex px-5">
                <li className="list-none text-2xl flex items-center gap-5">
                    <Link to={"/"}>
                    <li className=" text-white hover:scale-150 duration-300"><IoHomeSharp/></li>
                    </Link>
                    
                {/* {userData.email ? (
          <> */}
          {/* <li className="mt-2">
          <Link to="/cart">
            <div className="relative">
              <FaShoppingCart className="text-xl" />
            </div>
          </Link>
        </li> */}
        <Link to={"/cart"}>
                   <div className=" text-white relative flex justify-center items-center hover:scale-150 duration-300">
                   <li className=""><FaShoppingCart/></li>
                   <div className="absolute bg-white h-5 w-5 top-[-10px] right-[-10px] flex justify-center items-center rounded-full">
                    <span className="text-black text-sm font-semibold" >{basketData.length}</span>
                   </div>
                   </div>
                   </Link>
        <li className=" cursor-pointer" onClick={handleLogout}>
           
            <button className="bg-[#2a2a2a] dark:bg-slate-800 text-white p-2 rounded-md cursor-pointer hover:bg-black">
              LogOut
            </button>
          </li>
          
          {/* </>
          
        ) : (
          <> */}
          <Link to={"/login"}>
                    <li className=" text-white hover:scale-150 duration-300"><RiLoginBoxFill/></li>

                    </Link>
                    <Link to={"/signup"}>
                    <li className=" text-white hover:scale-150 duration-300"><TiUserAdd/></li>

                    </Link>
                    
          {/* </>
        )} */}

                   
                </li>
            </div>
           </header>
        </div>
    );
}

export default Header
