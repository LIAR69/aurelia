// import React from "react";
// // function Product() {
// //     return (
//         // <div >
//         // <div className="flex flex-col gap-2  w-80 border-2 border-slate-200 rounded-xl">
//         //     <img className="w-80 h-80 object-cover rounded-t-xl" src="https://img.freepik.com/free-photo/view-3d-laptop-device-with-screen-keyboard_23-2150714071.jpg?t=st=1720781461~exp=1720785061~hmac=203f9ada2c4239de8fa281e558842d9e6ea4ed0ca3543032cafc3daf10fd02be&w=1060"/>
//         //     <div className="p-5 flex flex-col ">
//         //     <div className=" gap-2 flex flex-col">
//         //         <p className="text-xl font-bold">name</p>
//         //         <p className="text-lg font-semibold truncate">description</p>
//         //     </div>
//         //     <div className="flex gap-4 py-2 justify-between">
//         //         <p>sellingPrice</p>
//         //         <del>
//         //             <p>price</p>
//         //         </del>
//         //     </div>
//         //     <button className="bg-red-400 py-1 w-full rounded-md mt-3">Add to cart</button>  
//         //     </div>
//         //     </div> 
           
//         // </div>
// //     );
// // }

// export default Product