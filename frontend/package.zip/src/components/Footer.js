import React from "react";
import './pagination.css';


function Footer() {
    return (
        <div class = "pagination">
        <a href = "" class = "active">1</a>
        <a href = "">2</a>
        <a href = "">3</a>
        <a href = "">4</a>
        <a href = "">5</a>
    </div>
    );
}

export default Footer