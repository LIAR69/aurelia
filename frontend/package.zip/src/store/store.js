import {configureStore} from '@reduxjs/toolkit'
import registerReducer from './userSlice'
import loginReducer from './loginslice'
import basketReducer from './basketSlice'

export const store = configureStore ({
    reducer:{ 
        user:registerReducer,
        user1:loginReducer,
        basket: basketReducer
    }
})

