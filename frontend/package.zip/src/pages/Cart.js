import React, { useState } from 'react'

function Cart() {
  const [count, setCount]= useState(0)

  const handleChangeName = ()=>{
    setCount(count + 1)
  }
  const handleChangeName1 = ()=>{
    setCount(count - 1)
  }

  const handleChangeName2 = ()=>{
    setCount(0)
  }

  return (
    <div >
      <p className='text-9xl font-semi-bold text-center'>{count}</p>
      
    <div className=' text-5xl my-6 font-semi-bold text-center'>
    <button onClick={handleChangeName} className='border-2 border-black rounded-xl my-7 bg-purple-600'>Increase</button>
    <button onClick={handleChangeName2} className='my-7 bg-blue-100'>Reset</button>
    <button onClick={handleChangeName1} className='border-2 border-black rounded-xl my-7 bg-green-600'>Decrease</button>
    
    </div>  
      
    </div>
  )
}

export default Cart
