import React from 'react'
import Products from '../components/Products'
function Womens() {
  return (
  
    <div  className=' bg-black flex flex-wrap gap-8 justify-center p-6'>
      
 <Products   
      image={ "https://www.justwatches.com/cdn/shop/products/Untitled-1_0003_W0443L4_1.jpg?v=1579102690&width=3000"}
      name={"Guess Sport Rose Gold Round Dial Women Quartz Analog Watch"}
      code = {"Product Code: RY382_NLP1_NLC"}
            price={12000}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/TWEL14803.png?v=1700720023&width=3000"}
      name={"Timex Fashion Women Rose Gold Round Dial Analog Quartz "}
      code = {"Product Code: AR11586_NLP1_N6LC"}
      price={5000}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/products/GW0410L4.jpg?v=1658490790&width=3000"}
      name={"Guess Crown Jewel Purple Dial Round Case Multi-Function Women Watch"}
      code = {"Product Code: AR11586_T54_NLC"}
      price={15000}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/Z05006L2MF.jpg?v=1703163237&width=3000"}
      name={"Gc Sport Chic Black Dial Round Case Quartz Analog Women Watch"}
      code = {"Product Code: YRO3216_NLP1_NLC"}
      price={26600}
/>      
<Products   
      image={ "https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw0713b276/images/Titan/Catalog/95283WM01_1.jpg?sw=800&sh=800"}
      name={"Titan Raga Showstopper Quartz Analog Rose Gold Dial Metal Strap Watch for Women"}
      code = {"Product Code: AR11586_RHT4_NLC"}
      price={10000}
/>      
<Products   
      image={ "https://asset.swarovski.com/images/$size_2000/t_swa103/b_rgb:ffffff,c_scale,dpr_2.0,f_auto,w_2000/5580345_png/passage-chrono-watch--swiss-made--leather-strap--red--rose-gold-tone-finish-swarovski-5580345.png"}
      name={"Passage Chrono watch Swiss Made, Leather strap, Red, Rose gold-tone finish"}
      code = {"Product Code: AR34286_NLP1_NLC"}
      price={35000}
/>      
<Products   
      image={ "https://asset.swarovski.com/images/$size_2000/t_swa103/b_rgb:ffffff,c_scale,dpr_2.0,f_auto,w_2000/5672931_png/octea-chrono-watch--swiss-made--leather-strap--green--rose-gold-tone-finish-swarovski-5672931.png"}
      name={"ctea Chrono watch Swiss Made, Leather strap, Green, Rose gold-tone finish"}
      code = {"Product Code: ARWVX86_NLP1_NLC"}
      price={38000}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/GW0475L1_1.jpg?v=1701856880&width=3000"}
      name={"Guess Cosmic Champagne Dial Round Case Multi-Function Women Watch"}
      code = {"Product Code: AR115RU_FEP1_NLC"}
      price={25500}
/>      
    </div>
  )
}


  
export default Womens