import React from"react";
import './card.css';
function Card(){
    return(
        <>
        <div class = "listt">
        <ul>Items to be bought
            <li>Shirts</li>
            <li>T-Shirts</li>
            <li>Shoes</li>
            <li>Watches</li>
        </ul>
        <h1 className="text-blue-700 text-3xl font-bold underline">
      Hello world! 
    </h1>
        </div>
        </>
    )
}
export default Card