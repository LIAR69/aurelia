import React from 'react'
import Products from '../components/Products'
function Home() {
  return (
  
    <div  className=' bg-black flex flex-wrap gap-8 justify-center p-6'>
      
      {/* <Product/>
      <Product/>
      <Product/>
      <Product/>
      <Product/> */}
      


 <Products   
      image={ "https://www.justwatches.com/cdn/shop/files/NAPTCS303.jpg?v=1693569665&width=3000"}
      name={"Nautica Tin Can Bay Blue Dial Round Case Quartz Analog Men Watch"}
            price={16000}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/PWWAA0523.jpg?v=1695927045&width=3000"}
      name={"Philipp Plein $Kull Synthetic Men Black Dial Quartz "}
      price={33000}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/Z14011G7MF_1.jpg?v=1709643349&width=3000"}
      name={"Gc One Sport Men Round Dial Quartz Analog Watch"}
      price={43300}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/GW0627G2.jpg?v=1700719547&width=3000"}
      name={"hGuess Parker Black Dial Round Case Multi-Function Men Watch"}
      price={12200}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/TW2U62000U9.jpg?v=1703152624&width=3000"}
      name={"Q Timex Blue Dial Round Case Quartz Analog Men Watch"}
      price={10000}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/PWCAA0521.jpg?v=1695882545&width=3000"}
      name={"Philipp Plein Nobile Men Blue Dial Quartz"}
      price={46000}
/>      
<Products   
      image={ "https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw4d00178e/images/Titan/Catalog/90174KD02_1.jpg?sw=800&sh=800"}
      name={"Titan Ceramic Fusion Automatic Blue Dial Silver Dual-Toned Stainless Steel"}
      price={27000}
/>      
<Products   
      image={ "https://www.armani.com/variants/images/1647597326828724/F/w2500.jpg"}
      name={"EMPORIO ARMANI Chronograph Brown Leather Watch"}
      price={30000}
/>      
    </div>
  )
}

  
export default Home