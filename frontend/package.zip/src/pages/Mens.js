import React from 'react'
import Products from '../components/Products'
function Mens() {
  return (
  
    <div  className=' bg-black flex flex-wrap gap-8 justify-center p-6'>
      
 <Products   
      id={121}
      image={ "https://www.justwatches.com/cdn/shop/files/NAPTCS303.jpg?v=1693569665&width=3000"}
      name={"Nautica Tin Can Bay Blue Dial Round Case Quartz Analog Men Watch"}
      code = {"Product Code: AR11586_NLP1_NLC"}
      price={16000}
/>      
<Products   
      id={122}

      image={ "https://www.armani.com/variants/images/1647597339323665/F/w2500.jpg"}
      name={"EMPORIO ARMANI Chronograph Black Leather Watch"}
      code = {"Product Code: A22586_NLP1_KBC"}
      price={33000}
/>      
<Products   
      id={123}

      image={ "https://www.justwatches.com/cdn/shop/files/Z14011G7MF_1.jpg?v=1709643349&width=3000"}
      name={"Gc One Sport Men Round Dial Quartz Analog Watch"}
      code = {"Product Code: SQ121586_NLP1_NLC"}
      price={43300}
/>      
<Products   
      id={124}

      image={ "https://www.justwatches.com/cdn/shop/files/GW0627G2.jpg?v=1700719547&width=3000"}
      name={"hGuess Parker Black Dial Round Case Multi-Function Men Watch"}
      code = {"Product Code: AR11586_LMS9_NLC"}
      price={12200}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/TW2U62000U9.jpg?v=1703152624&width=3000"}
      name={"Q Timex Blue Dial Round Case Quartz Analog Men Watch"}
      code = {"Product Code: CR71586_NLP1_NLC"}
      price={10000}
/>      
<Products   
      image={ "https://www.armani.com/variants/images/1647597339323671/F/w2500.jpg"}
      name={"EMPORIO ARMANI Chronograph Two-Tone Stainless Steel Watch"}
      code = {"Product Code: SU11586_NLP1_PLC"}
      price={32000}
/>      
<Products   
      image={ "https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw4d00178e/images/Titan/Catalog/90174KD02_1.jpg?sw=800&sh=800"}
      name={"Titan Ceramic Fusion Automatic Blue Dial Silver Dual-Toned Stainless Steel"}
      code = {"Product Code: AR11586_D321_NLC"}
      price={27000}
/>      
<Products   
      image={ "https://www.justwatches.com/cdn/shop/files/VE7E00623.jpg?v=1695373083&width=3000"}
      name={"Versace Medusa Black Dial Round Case Swiss Quartz Men Watch"}
      code = {"Product Code: UY47593_NLP1_NLC"}
      price={153500}
/>      
    </div>
  )
}


  
export default Mens